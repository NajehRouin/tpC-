﻿namespace Forme1_Tp1
{
    partial class Form1
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Txt_Saisie = new System.Windows.Forms.TextBox();
            this.btn_Ajouter = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btn_list1_to_list2 = new System.Windows.Forms.Button();
            this.btn_list2_to_list1 = new System.Windows.Forms.Button();
            this.listBox2 = new System.Windows.Forms.ListBox();
            this.btn_effacer_1 = new System.Windows.Forms.Button();
            this.btn_effacer_2 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Beige;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(216, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tapez une texte pour l\'inclure dans  la liste 1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(37, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Saisie";
            // 
            // Txt_Saisie
            // 
            this.Txt_Saisie.Location = new System.Drawing.Point(90, 54);
            this.Txt_Saisie.Name = "Txt_Saisie";
            this.Txt_Saisie.Size = new System.Drawing.Size(100, 20);
            this.Txt_Saisie.TabIndex = 2;
            // 
            // btn_Ajouter
            // 
            this.btn_Ajouter.Location = new System.Drawing.Point(310, 57);
            this.btn_Ajouter.Name = "btn_Ajouter";
            this.btn_Ajouter.Size = new System.Drawing.Size(75, 23);
            this.btn_Ajouter.TabIndex = 3;
            this.btn_Ajouter.Text = "Ajouter";
            this.btn_Ajouter.UseVisualStyleBackColor = true;
            this.btn_Ajouter.Click += new System.EventHandler(this.btn_Ajouter_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(28, 110);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(131, 95);
            this.listBox1.TabIndex = 4;
            // 
            // btn_list1_to_list2
            // 
            this.btn_list1_to_list2.Location = new System.Drawing.Point(202, 133);
            this.btn_list1_to_list2.Name = "btn_list1_to_list2";
            this.btn_list1_to_list2.Size = new System.Drawing.Size(75, 23);
            this.btn_list1_to_list2.TabIndex = 5;
            this.btn_list1_to_list2.Text = "-->";
            this.btn_list1_to_list2.UseVisualStyleBackColor = true;
            this.btn_list1_to_list2.Click += new System.EventHandler(this.btn_list1_to_list2_Click);
            // 
            // btn_list2_to_list1
            // 
            this.btn_list2_to_list1.Location = new System.Drawing.Point(202, 182);
            this.btn_list2_to_list1.Name = "btn_list2_to_list1";
            this.btn_list2_to_list1.Size = new System.Drawing.Size(75, 23);
            this.btn_list2_to_list1.TabIndex = 6;
            this.btn_list2_to_list1.Text = "<--";
            this.btn_list2_to_list1.UseVisualStyleBackColor = true;
            this.btn_list2_to_list1.Click += new System.EventHandler(this.btn_list2_to_list1_Click);
            // 
            // listBox2
            // 
            this.listBox2.FormattingEnabled = true;
            this.listBox2.Location = new System.Drawing.Point(325, 110);
            this.listBox2.Name = "listBox2";
            this.listBox2.Size = new System.Drawing.Size(120, 95);
            this.listBox2.TabIndex = 7;
            // 
            // btn_effacer_1
            // 
            this.btn_effacer_1.Location = new System.Drawing.Point(40, 236);
            this.btn_effacer_1.Name = "btn_effacer_1";
            this.btn_effacer_1.Size = new System.Drawing.Size(75, 23);
            this.btn_effacer_1.TabIndex = 8;
            this.btn_effacer_1.Text = "Effacer";
            this.btn_effacer_1.UseVisualStyleBackColor = true;
            this.btn_effacer_1.Click += new System.EventHandler(this.btn_effacer_1_Click);
            // 
            // btn_effacer_2
            // 
            this.btn_effacer_2.Location = new System.Drawing.Point(343, 236);
            this.btn_effacer_2.Name = "btn_effacer_2";
            this.btn_effacer_2.Size = new System.Drawing.Size(75, 23);
            this.btn_effacer_2.TabIndex = 9;
            this.btn_effacer_2.Text = "Effacer";
            this.btn_effacer_2.UseVisualStyleBackColor = true;
            this.btn_effacer_2.Click += new System.EventHandler(this.btn_effacer_2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(542, 299);
            this.Controls.Add(this.btn_effacer_2);
            this.Controls.Add(this.btn_effacer_1);
            this.Controls.Add(this.listBox2);
            this.Controls.Add(this.btn_list2_to_list1);
            this.Controls.Add(this.btn_list1_to_list2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.btn_Ajouter);
            this.Controls.Add(this.Txt_Saisie);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "ListeBox";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Txt_Saisie;
        private System.Windows.Forms.Button btn_Ajouter;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btn_list1_to_list2;
        private System.Windows.Forms.Button btn_list2_to_list1;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.Button btn_effacer_1;
        private System.Windows.Forms.Button btn_effacer_2;
    }
}

