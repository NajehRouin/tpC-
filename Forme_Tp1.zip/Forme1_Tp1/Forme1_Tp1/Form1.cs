﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Forme1_Tp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
        private void btn_Ajouter_Click(object sender, EventArgs e)
        {
            if (this.Txt_Saisie.Text != "")
            {
                listBox1.Items.Add(this.Txt_Saisie.Text);
                this.Txt_Saisie.Focus();
                this.Txt_Saisie.Clear();

            }
            else
            {
                MessageBox.Show("svp saisier une texte pour l'ajouter","Error",MessageBoxButtons.OK,MessageBoxIcon.Information);
                this.Txt_Saisie.Focus();
            }
        }

        private void btn_list1_to_list2_Click(object sender, EventArgs e)
        {
            if (this.listBox1.Items.Count >0)
            {
                if (this.listBox1.SelectedItems.Count == 1)
                {

                    listBox2.Items.Add(this.listBox1.SelectedItem);
                    this.listBox1.Items.Remove(this.listBox1.SelectedItem);
                }
                else
                {
                    MessageBox.Show("choisissez un element dans la  liste svp", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("la liste est vide ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btn_list2_to_list1_Click(object sender, EventArgs e)
        {
            if (this.listBox2.Items.Count > 0)
            {
                if (this.listBox2.SelectedItems.Count == 1)
                {

                    listBox1.Items.Add(this.listBox2.SelectedItem);
                    this.listBox2.Items.Remove(this.listBox2.SelectedItem);
                }
                else
                {
                    MessageBox.Show("choisissez un element dans la liste svp  ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("la liste est vide ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btn_effacer_1_Click(object sender, EventArgs e)
        {
            if (listBox1.Items.Count > 0)
            {
                if (MessageBox.Show("voulez-vous supprimer", "waring", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    this.listBox1.Items.Clear();
                }
            }
            else
            {
                MessageBox.Show("la liste est vide ");
            }

        }

        private void btn_effacer_2_Click(object sender, EventArgs e)
        {
            if (listBox2.Items.Count > 0)
            {
                if (MessageBox.Show("voulez-vous deplacer et  supprimer tous les elements de la  liste "
                    , "waring", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    this.listBox1.Items.AddRange(this.listBox2.Items);
                    this.listBox2.Items.Clear();
                }

            }
            else
            {
                MessageBox.Show("la liste est vide ");
            }
        }
    }
}
